#! /bin/sh

config.app
sleep 1
freetype_test.app &

