#!/bin/sh

hciconfig hci0 down
