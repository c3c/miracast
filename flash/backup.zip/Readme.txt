Rootfs for NAND Flash
